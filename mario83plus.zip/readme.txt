Super Mario 83+ v2.0
====================


This release of Super Mario 83+ is not distributed officially.


The repackaged archive was submitted to CalcGames.org by Chase Taylor (taylorchase@hotmail.com)